import tkinter as tk

root = tk.Tk()
root.after(1000, root.quit)
root.mainloop()
