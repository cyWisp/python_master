import tkinter as tk
from tkinter import ttk

# Start coding here


class Application(tk.Tk):
    """Application root window"""

if __name__ == "__main__":
    app = Application()
    app.mainloop()
