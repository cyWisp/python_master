from .submodule_2 import submodule_a
