from abq_data_entry.application import Application

app = Application()
app.mainloop()
