import tkinter as tk
from tkinter import messagebox

messagebox.showinfo(
    title='This is the title',
    message="This is the message",
    detail='This is the detail'
)
