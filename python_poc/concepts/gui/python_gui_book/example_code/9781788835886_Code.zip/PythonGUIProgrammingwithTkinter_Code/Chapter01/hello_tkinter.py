"""Hello World application for Tkinter"""


from tkinter import *
from tkinter.ttk 
import *

root = Tk()

label = Label(root, text="Hello World")
label.pack()
root.mainloop()
