from .application import Application


def main():
    app = Application()
    app.mainloop()
