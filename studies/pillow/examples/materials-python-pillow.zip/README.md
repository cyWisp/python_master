# Image Repository For Tutorial 'Image Processing With The Python Pillow Library'

This image repository accompanies [Image Processing With The Python Pillow Library](https://realpython.com/image-processing-with-the-python-pillow-library/). It contains images you'll need while exploring the code explained in the tutorial.

## Image Credits

- [`buildings.jpg`](buildings.jpg): [Pixabay](https://pixabay.com/photos/buildings-amsterdam-historic-6778915/) by [memorycatcher](https://pixabay.com/users/memorycatcher-168384/)
- [`cat.jpg`](cat.jpg): [Pixabay](https://pixabay.com/photos/cat-pet-feline-animal-fur-3591348/) by [mabelamber](https://pixabay.com/users/mabelamber-1377835/)
- [`house_left.jpg`](house_left.jpg): [Pixabay](https://pixabay.com/vectors/house-houses-spot-the-difference-3208132/) by [creozavr](https://pixabay.com/users/creozavr-2567670/)
- [`house_right.jpg`](house_right.jpg): [Pixabay](https://pixabay.com/vectors/house-houses-spot-the-difference-3208132/) by [creozavr](https://pixabay.com/users/creozavr-2567670/)
- [`monastery.jpg`](monastery.jpg): [Pixabay](https://pixabay.com/photos/monastery-vault-cloister-columns-6560623/) by [tama66](https://pixabay.com/users/tama66-1032521/)
- [`strawberry.jpg`](strawberry.jpg): [Pixabay](https://pixabay.com/photos/strawberry-fruit-food-fresh-6648685/) by [geoluro11](https://pixabay.com/users/geoluro11-15863448/)
