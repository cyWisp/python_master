#!/usr/bin/env python
import tweepy, json
from auth import authenticate, AUTH, create_api_object
import sys

if __name__ == '__main__':

	api = create_api_object(AUTH)
	if not authenticate(api):
		sys.exit()


	test = 'JosephPrince'

	user = api.get_user(test)
	followers = api.followers("JosephPrince", cursor=-1, count=30)
	f_count = user.followers_count

	print(f'Number of follwers for {user}: {f_count}')

	# total = 0
	# page = -1
	# while total <= int(f_count):
	# 	followers = api.followers("JosephPrince", cursor=page, count=30)
	# 	for f in followers[0]:
	# 		if not f.following:
	# 			print(f"Following {f.screen_name}")
	# 			f.follow()
	# 		total += 1
	# 	page += 1
			

	#print(f"Total followers: {f_count}")
	#print(len(followers[0]))
	
	#for f in followers[0]:
	#	print(f.screen_name)

	#print("\n\n")

	#for f in followers[1]:
	#	print(f)
	



	

